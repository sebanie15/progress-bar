from setuptools import setup

setup(
    name='ProgressBar',
    version='0.1',
    author='Sebastian Nieciag',
    author_email='sebanie15@gmail.com',
    license='MIT',
    description='Progress bar utilities',
    packages=['progressBar'],
    requires=[]
)